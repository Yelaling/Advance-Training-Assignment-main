package com.books;

import java.sql.*;
import java.util.*;

public class User {
	private String first_name;
	private String address;
	private String email;
	private String user_name;
	private String password;

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	private boolean logged = false;

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmail() {
		return email;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return address;
	}


	public void login() {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = getConnection();
			ps = con.prepareStatement("select user_name,email,first_name,address from Users where user_name = ? and password= ?");
			ps.setString(1, user_name);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();

			logged = false;

			if (rs.next()) {
				email = rs.getString("email");
				address = rs.getString("address");
				first_name = rs.getString("first_name");
				logged = true;
			}

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
			clean(con, ps);
		}

	} // end of isValid

	public String updateProfile(String newpassword) {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			con = getConnection();
			String cmd = "update Users set email=?, first_name = ? , address =? ";

			if (!newpassword.equals(""))
				cmd += " , password = '" + newpassword + "'";

			cmd = cmd + " where userid = ?";

			ps = con.prepareStatement(cmd);
			ps.setString(1, email);
			ps.setString(2, first_name);
			ps.setString(3, address);

			int cnt = ps.executeUpdate();
			if (cnt == 1) {
				if (!newpassword.equals(""))
					password = newpassword;
				return null;
			} else
				return "Invalid User. Unable to update profile.";

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return ex.getMessage();
		} finally {
			clean(con, ps);
		}

	} // end of updateProfile

	public String registerUser() {
		Connection con = null;
		PreparedStatement ps = null;

		try {
			con = getConnection();
			ps = con.prepareStatement("insert into Users values (?,?,?,?,?,?)");
			ps.setString(2, user_name);
			ps.setString(3, password);
			ps.setString(4, email);
			ps.setString(5, address);
			ps.setString(6, first_name);
			ps.executeUpdate();
			logged = true;
			return null;
		} catch (Exception ex) {
			return ex.getMessage();
		} finally {
			clean(con, ps);
		}
	}

	public boolean isLogged() {
		return logged;

	}

	int j = 1;

	public int getNextUserid(Connection con) throws Exception {
		int nextuserid = j;
		j++;
		// rs.close();

		return nextuserid;

	}

	public void clean(Connection con, PreparedStatement ps) {
		try {
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	public Connection getConnection() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");

		java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookstore", "root",
				"12345678");
		return con;
	}

} //