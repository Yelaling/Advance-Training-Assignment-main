package com.books;

public class books implements java.io.Serializable {
	private int Book_Id;
	private String Book_Name, Author;
	private int Price;

	public books(String Author,int Book_Id , String Book_Name, int Price) {
		this.Book_Id = Book_Id;
		this.Book_Name = Book_Name;
		this.Price = Price;
		this.Author= Author;
	}

	public int getBook_Id() {
		return Book_Id;
	}

	public void setBook_Id(int book_Id) {
		Book_Id = book_Id;
	}

	public String getBook_Name() {
		return Book_Name;
	}

	public void setBook_Name(String book_Name) {
		Book_Name = book_Name;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}

	public void addQty(int i) {
		// TODO Auto-generated method stub
		
	}

	
}
