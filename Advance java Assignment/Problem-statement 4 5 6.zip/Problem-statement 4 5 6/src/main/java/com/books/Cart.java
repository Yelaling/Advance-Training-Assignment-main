package com.books;
import java.util.*;
import java.sql.*;
import com.books.*;
import javax.ejb.*;
import javax.naming.*;
import com.books.order.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;  




public class Cart
{
   ArrayList items = new ArrayList();
   
   public books find(String Book_Name)
   {
     Iterator itr = items.iterator();
     books itm;
     while ( itr.hasNext())
     {
       itm =  (books) itr.next();
       if ( itm.getBook_Name().equals(Book_Name))
       {
          return itm;
       }
     }  // end of while

     return null;
   }
   
   // adds an item if not already existing
  // otherwise add 1 to qty
   public void addItem(String Book_Id )
   {
     //check whether isbn is already present
     books item =  find(Book_Id);
     if ( item != null)
       item.addQty(1);
     else
     {
       // get detais from Books tables
     
       Connection con =null;
       com.books.User  user  = new com.books.User();
       try
       {
        con = user.getConnection();
        PreparedStatement ps = con.prepareStatement("select title,price from books where Book_Id = ? ");
        ps.setString(1,Book_Id);

        ResultSet rs  = ps.executeQuery();
        if ( rs.next())
        {
          item = new books(Book_Id, 0, rs.getString(1), 0 );
          items.add(item);
        }

        rs.close();
        ps.close();

       }
       catch(Exception ex)
       {
         System.out.println(ex.getMessage());
       }
       finally
       {  
         try {con.close();} catch(Exception ex) {}
       }
     }  // end of else
   }       

   public  ArrayList  getItems()
   {  return items; }

   public  void removeItem(String isbn)
   {
       books item = find(isbn);
       if  ( item != null)
           items.remove(item);
   } // end or removeItem

    public void clearAll()
    {
       items.clear();
   }

   public void updateQty(String Book_Id, int price)
   {
        books  item = find(Book_Id);
        if ( item != null)
          item.setPrice(price);;
   } // end of updateQty()


  public boolean finalizeOrder(int user_Id,int total) 
  {
     
	  try {
			Scanner sc=new Scanner(System.in);
			
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();
			
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test";
			String user="root";
			String pass="12345678";
			Connection con=DriverManager.getConnection(url,user,pass);
			String sql="INSERT INTO `Order_details` ('Order_Id', `Book_Id`, `Order_date`, `Cust_Name`, `Phone_No`, `Quantity`) VALUES (NULL, '"+user_Id+"', '"+now+"', '"+total+"', 'a', '2')";
			Statement stmt=con.createStatement();
			stmt.executeUpdate(sql);
			con.close();
			System.out.println("Record inserted");
			
			return true;
			
		} catch(Exception ex)
	   	{
		     System.out.println( ex.getMessage());
		     return false;
		 
		   }

  } 



  public boolean cancelOrder(int ordid) 
  {
     
   try
   {
      Context ctx = getInitialContext();  
      // get access to bean

      OrderHome home = (OrderHome)  ctx.lookup("obs.order");
      Order order = home.create();

      return order.cancelOrder(ordid);
     
   }
   catch(Exception ex)
   {
     System.out.println( ex.getMessage());
     return false;
 
   }


  } // end of  finalizeOrder

  public Context getInitialContext() 
  {
  
  String JNDI_FACTORY="weblogic.jndi.WLInitialContextFactory";

  try
  {
   Hashtable env = new Hashtable();
   env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
   env.put(Context.PROVIDER_URL,"t3://localhost:7001");
   return new InitialContext(env);
  }
  catch(Exception ex)
  { 
    System.out.println(ex.getMessage()); 
    return null;
  }

 }

}

   


