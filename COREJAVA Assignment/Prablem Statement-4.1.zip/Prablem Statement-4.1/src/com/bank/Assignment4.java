package com.bank;

public class Assignment4 
{
	public static void main(String[] args)
	{
		
		Calculate calculate = new Calculate(123456789, 56000);
		
		calculate.accept(460,670);
		
		calculate.compute();
		calculate.display();
		
		
	}

}
