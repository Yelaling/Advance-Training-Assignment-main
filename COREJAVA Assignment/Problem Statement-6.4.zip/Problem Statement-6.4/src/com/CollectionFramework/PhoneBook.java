package com.CollectionFramework;

import java.util.ArrayList;
import java.util.List;

public class PhoneBook {

	private static final List<Contact> Phone = null;
	private List<Contact> PhoneBook=new ArrayList<Contact>();
   
    public Contact viewContactGivenPhone(long phoneNumber)
    {
        Contact obj=new Contact("yellaling","poojari",8722424056l);
        for(Contact obj1:Phone)
        {
            if(obj1.getPhonenumber()==phoneNumber)
            {
                obj=obj1;
            }
        }
        return obj;
    }
   
}