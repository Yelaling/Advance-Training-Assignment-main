package com.abstractclassandinterface;

public abstract class Paino extends Instrument {
	@Override
	public void play() {
		System.out.println("Piano is playing  tan tan tan tan");

	}
}
