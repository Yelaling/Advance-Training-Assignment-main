package com.abstractclassandinterface;

public abstract class Instrument {
	public abstract void play();
}
