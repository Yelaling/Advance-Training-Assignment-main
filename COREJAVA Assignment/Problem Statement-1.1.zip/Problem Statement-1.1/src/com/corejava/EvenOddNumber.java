package com.corejava;

import java.util.Scanner;

public class EvenOddNumber 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number = ");
		
		int n = sc.nextInt();
		
		System.out.println("Even number From 1 to 10 "+n+" are: ");
		
		for(int i=1; i<=10; i++)
		{
			if(i%2 ==0)
			{
				System.out.println(i + " ");
			}
		}
	}

}
