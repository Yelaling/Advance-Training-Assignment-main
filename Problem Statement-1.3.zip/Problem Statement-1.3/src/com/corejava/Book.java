package com.corejava;

public class Book
{
	private String Bookname;
	private String BookPrice;
	
	public String getBookname() {
		return Bookname;
	}
	public void setBookname(String bookname) {
		Bookname = bookname;
	}
	public String getBBookPrice() {
		return BookPrice;
	}
	public void setBBookPrice(String bBookPrice) {
		BookPrice = bBookPrice;
	}
	
	
	
	
	

}
