package com.CollectionFramework;

public class Contact 
{
	private String firstname;
	private String lastname;
	private long phonenumber;
	
	
	
	
	 public String getFirstname() {
		return firstname;
	}




	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}




	public String getLastname() {
		return lastname;
	}




	public void setLastname(String lastname) {
		this.lastname = lastname;
	}




	public long getPhonenumber() {
		return phonenumber;
	}




	public void setPhonenumber(long phonenumber) {
		this.phonenumber = phonenumber;
	}




	public Contact(String firstName, String lastName, long phoneNumber) 
	{
		    super();
		    this.firstname = firstName;
		   
		    this.phonenumber = phoneNumber;
		    this.lastname=lastname;
		    
		  }
	
	

}
